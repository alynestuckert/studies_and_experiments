class Cliente:
    lista_clientes = []

    def __init__(self, nome, email, telefone, endereco):
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.endereco = endereco
        Cliente.lista_clientes.append(self)

    # Magic method para organizar os atributos passados, dessa forma o retorno da classe seré essa string

    def __str__(self):
        return f"Nome: {self.nome}\nEmail: {self.email}\nTelefone: {self.telefone}\nEndereço: {self.endereco}"

    def exibir_dados(self):
        print(self)
    
    # Salvar os cadastros em um arquivo de texto
    def salvar_cadastro():
        with open("clientes.txt", "w") as file:
            for cliente in Cliente.lista_clientes:
                file.write(str(cliente) + "\n---\n")
    
    # Exibir clientes cadastrados recentemente, exibir a lista criada
    def exibir_lista_clientes():
        if Cliente.lista_clientes:
            print("Lista de Clientes:")
            for cliente in Cliente.lista_clientes:
                print(cliente)
                print("---")
        else:
            print("Nenhum cliente cadastrado.")
